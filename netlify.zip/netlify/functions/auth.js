import { neon } from '@netlify/neon-http';
const sql = neon(); // Автоматически берет переменную


const sql = neon(process.env.NETLIFY_DATABASE_URL || 'postgres://neondb_owner:npg_osSm1VMGC3lg@ep-old-cloud-ajq74fba-pooler.c-3.us-east-2.aws.neon.tech/neondb?sslmode=require');

export default async function handler(req, res) {
  try {
    if (req.method === 'POST') {
      const { action, email, password, fullName, phone, code } = req.body;
      
      if (action === 'register') {
        // Проверяем код
        if (code !== '000000') {
          return res.status(400).json({ error: 'Неверный код' });
        }
        
        // Проверяем, есть ли пользователь
        const [existing] = await sql`
          SELECT * FROM users WHERE email = ${email}
        `;
        
        if (existing) {
          return res.status(400).json({ error: 'Пользователь существует' });
        }
        
        // Создаем пользователя
        const [newUser] = await sql`
          INSERT INTO users (full_name, phone, email, password, role) 
          VALUES (${fullName}, ${phone}, ${email}, ${password}, 'user') 
          RETURNING *
        `;
        
        return res.json({ success: true, user: newUser });
      }
      
      if (action === 'login') {
        const [user] = await sql`
          SELECT * FROM users WHERE email = ${email} AND password = ${password}
        `;
        
        if (!user) {
          return res.status(401).json({ error: 'Неверные данные' });
        }
        
        return res.json({ success: true, user });
      }
    }
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
